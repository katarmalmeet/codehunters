<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Case Grid | Where Legal Cases Meet Efficiency</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Law Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,400,300,600,700|Six+Caps' rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>


<style>
	.feature {
		background: #efd4d0;
		margin-bottom: 60px;
	}
	#homie {
		margin-left: 120px;
	}

	li.space {
		margin-left: 27px;
	}
	div.container {
		margin: 20px;
		padding: 0px 0px;
		width: 90%;
	}
	
	.head-main {
		width: 300px;
	}

</style>


</head>
<body>	<!--header-top-starts-->
	<div class="header-top">
		<div class="container">
			<div class="head-main">
				<h1>
					<a href="index3.php"><img src="images/law_icon.png" alt="Image File" height="50">CaseGrid</a>
				</h1>
			</div>
			<div class="navigation">
				<nav class="navbar navbar-default" role="navigation">
					<!--/.navbar-header-->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">
							<li class="active" id="homie"><a href="index3.php">Home</a></li>
							<li class="space"><a href="case_inquiry.php">Case Inquiry</a></li>
							<li class="space"><a href="lawyer.php">Hire Lawyer</a></li>
							<li class="space"><a href="legal_google.php">Legal Google</a></li>
							<li class="space"><a href="about.php">About</a></li>
							<li class="space"><a href="contact.php">Contact</a></li>
						</ul>
					</div>
					<!--/.navbar-collapse-->
				</nav>
			</div>
			<div class="hea-rgt">
				<a href="logout.php">Logout</a>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<!--header-top-end-->
	<!--start-header-->
	<!--
	
	<div class="header">
		<div class="container">
			<div class="head">
				<div class="soc">
					<ul>
						<li><a href="#"><span class="fb"> </span></a></li>
						<li><a href="#"><span class="twit"> </span></a></li>
						<li><a href="#"><span class="pin"> </span></a></li>
						<li><a href="#"><span class="rss"> </span></a></li>
						<li><a href="#"><span class="drbl"> </span></a></li>
						<div class="clearfix"></div>
					</ul>
				</div>
				<div class="header-right">
					<div class="search-bar">
						<form>
							<input type="text" value="Search" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search';}">
							<input type="submit" value="">
						</form>
					</div>
				</div>
				
					<div class="clearfix"></div>
			</div>
		</div>
	</div>	
	
	-->
	<!-- script-for-menu -->
	<!-- script-for-menu -->
		<script>
			$("span.menu").click(function(){
				$(" ul.navig").slideToggle("slow" , function(){
				});
			});
		</script>
	<!-- script-for-menu -->
				

	<!-- banner-starts -->
	<div class="banner-1">
		
	</div>
	<!--banner-end-->
	<div class="mainbody">
		<!--resource-->
		<div class="resource">
			<div class="container">
				<div class="col-md-8 resource-lft">
					<h3>ABOUT US</h3>
					<div class="res-top">
						
						<div class="col-md-8">
							
							<h1 style="color:  #8a6d3b;" >Introduction</h1>
							<p><h4 style="color: #333333; font-size: 16px; font-family:Open sans,sans sans-serif">At CaseGrid, we understand that the world of law can be intricate and demanding, often requiring meticulous attention to detail and organization. Whether you're a legal professional, a law firm, or an individual handling your own legal matters, our platform is designed to simplify every aspect of your legal case management process</h4>
								</p>
						</div>
						
					</div><br>
					<br>
					<div class="res-top">
						<br>
						<div class="col-md-8 "><br>
							<br>
							<h1 style="color:  #8a6d3b;">Mission and Vision</h1>
							<p><h4 style="color: #333333; font-size: 16px; font-family: sans-serif; ">At CaseGrid, we understand that the world of law can be intricate and demanding, often requiring meticulous attention to detail and organization. Whether you're a legal professional, a law firm, or an individual handling your own legal matters, our platform is designed to simplify every aspect of your legal case management process</h4>
								<p><h4 style="color: #333333; font-size: 16px; font-family: sans-serif;">At CaseGrid, our mission is to empower legal professionals, law firms, and individuals with the tools and resources they need to navigate the complexities of the legal system efficiently and effectively. We are committed to simplifying the world of court case management, streamlining processes, and enhancing collaboration, all while prioritizing the utmost security and compliance.</h4></p>
						</div>
						
					</div>
				</div>
				<div class="col-lg">
					<h3> Values and Principle </h3>
					<p><h4>Accessibility:</h4> Ensure that the platform is accessible to all users, including those with disabilities. </p>
					<p><h4>Security:</h4> Prioritize the security of user data and case information. Implement robust encryption and data protection measures to safeguard sensitive legal information from unauthorized access or breaches. </p>
					<p><h4>User-Centric:</h4> Always put the needs and interests of users first. </p>
					<p><h4>Compliance:</h4> Stay up-to-date with all relevant laws, regulations, and industry standards related to legal case management </p>
					<p><h4>Data Privacy:</h4> Respect and protect user privacy by adhering to data privacy laws and providing users with control  </p>
						
				</div>
				<br><br>
				<div class="about1-bottom2" style="background-color: rgba(255, 228, 196, 0.404);">
						<div class="col-md-4 about1-bottom1">
							<span></span>
							<h3>Ensure Compliance</h3>
							<p> CaseGrid is dedicated to helping users stay compliant with court procedures, deadlines, and regulations. We provide automated reminders and tools to ensure no critical dates are missed.</p>
						</div>
						<div class="col-md-4 about1-bottom1">
							
							<h3>Promote Accessibility</h3>
							<p>We believe that access to legal information should be convenient and available at any time, from anywhere. CaseGrid's ensures that users can manage their cases seamlessly, whether in the office or on the go.</p>
						</div>
						<div class="col-md-4 about1-bottom1">
							
							<h3>Drive Legal Success</h3>
							<p> Ultimately, our mission is to drive legal success for our users. We want to be the trusted partner that empowers legal professionals to achieve favorable outcomes for their clients and themselves. </p>
						</div>
					<div class="clearfix"> </div>
				</div>
			</diV>
		</div>
		<!--resource-end-->
	</div>
	<!-- footer-starts -->
	<div class="footer">
		<div class="container">
				<div class="col-md-4 contact-left">
				<h4>Address</h4>
					<div class="cont-tp">
						<span class="glyphicon glyphicon-map-marker" aria-hidden="true">
					</span></div>
					
					<address>
						Nr. Vasantnagar Township, <br>Gota-Ognaj Road, <br>Ahmedabad, GUJARAT- 382470<br>
					</address>
				</div>
				<div class="col-md-4 contact-left">
				<h4>Phone/Fax</h4>
					<div class="cont-tp">
						<span class="glyphicon glyphicon-phone" aria-hidden="true">
					</span></div>
					
					<p>Phone : +91-9510900587 </p>
					<p>Mail : info@aitindia.in</p>
					<p>Fax : +1234567890 </p>
				</div>
				<div class="col-md-4 contact-left">
				<h4>Newsletter</h4>
					<div class="cont-tp">
						<span class="glyphicon glyphicon-envelope" aria-hidden="true">
					</span></div>
					<form>
						<input type="text" value="Enter Your email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter Your email';}">
						<input type="submit" value="Subscribe">
					</form>
				</div>
				<div class="clearfix"></div>
			
			<div class="footer-text">
				<p>&copy; 2023 Legal Case Management. All rights reserved.</p>
			</div>
		</div>
	</div>
	<!-- footer-end -->
</body>
</html>