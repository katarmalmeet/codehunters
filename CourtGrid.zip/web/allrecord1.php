<table   class="table table-striped table-responsive">
			<tr>
				<th>ID</th>
				<th>Case Name</th>
				<th>Case Description</th>
				

			</tr>
			<?php
			require('config1.php');
			$db = new db;
			$result=$db->getAllEmployee();
			while($row=mysqli_fetch_array($result)){
				echo "<tr>
					<td>".$row['emp_id']."</td>
					<td>".$row['name']."</td>
					<td>".$row['phone']."</td>
					
					
				</tr>";
			}
			$db->closeCon();
			?>
</table>