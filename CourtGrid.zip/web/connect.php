<?php
$con=mysqli_connect('localhost','root','','login_register');
if(!$con){
    die(mysqli_error("Error"+$con));
}

?>