<!DOCTYPE html>
<html>
<head>
<title>Case Grid | Where Legal Cases Meet Efficiency</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,400,300,600,700|Six+Caps' rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>

<style>
	.feature {
		background: #ebcdc937;
		margin-bottom: 60px;
	}
	#homie {
		margin-left: 120px;
	}

	li.space {
		margin-left: 27px;
	}
	div.container {
		margin: 20px;
		padding: 0px 0px;
		width: 90%;
	}
	.head-main {
		width: 300px;
	}
	

</style>

</head>
<body>
	<!--header-top-starts-->
	<div class="header-top">
		<div class="container">
			<div class="head-main">
				<h1>
					<a href="index.html"><img src="images/law_icon.png" alt="Image File" height="55">&nbsp;CaseGrid</a>
				</h1>
			</div>
			<div class="navigation">
				<nav class="navbar navbar-default" role="navigation">
					<!--/.navbar-header-->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">
							<li class="active" id="homie"><a href="index.html">Home</a></li>
							<li class="space"><a href="registration.php">Case Inquiry</a></li>
							<li class="space"><a href="registration.php">Hire Lawyer</a></li>
							<li class="space"><a href="registration.php">Legal Google</a></li>
							<li class="space"><a href="registration.php">About</a></li>
							<li class="space"><a href="registration.php">Contact</a></li>
						</ul>
					</div>
					<!--/.navbar-collapse-->
				</nav>
			</div>
			<div class="hea-rgt">
				<a href="registration.php">Login / Register</a>
			</div>
		</div>
	</div>
	<!--header-top-end-->
	<!--start-header-->
	<!--
	
	<div class="header">
		<div class="container">
			<div class="head">
				<div class="soc">
					<ul>
						<li><a href="#"><span class="fb"> </span></a></li>
						<li><a href="#"><span class="twit"> </span></a></li>
						<li><a href="#"><span class="pin"> </span></a></li>
						<li><a href="#"><span class="rss"> </span></a></li>
						<li><a href="#"><span class="drbl"> </span></a></li>
						<div class="clearfix"></div>
					</ul>
				</div>
				<div class="header-right">
					<div class="search-bar">
						<form>
							<input type="text" value="Search" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search';}">
							<input type="submit" value="">
						</form>
					</div>
				</div>
				
					<div class="clearfix"></div>
			</div>
		</div>
	</div>	
	
	-->
	<!-- script-for-menu -->
	<!-- script-for-menu -->
		<script>
			$("span.menu").click(function(){
				$(" ul.navig").slideToggle("slow" , function(){
				});
			});
		</script>
	<!-- script-for-menu -->
				

	<!-- banner-starts -->
	<div class="banner">
		<div class="container">
			<div class="banner-top">
				<section class="slider">
					<div class="flexslider">
						<ul class="slides">
							<li>	
								<div class="banner-text">
									<h2>&nbsp;&nbsp;&nbsp;“Justice delayed is Justice denied”<br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - William E. Gladstonemy</h2>
								</div>
							</li>
							<li>	
								<div class="banner-text">
									<h2>“"Injustice anywhere is a threat to justice everywhere”<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - Martin Luther King Jr.</h2>
								</div>
							<li>	
								<div class="banner-text">
									<h2>“"The law is the witness and external deposit of our moral life”<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - Oliver Wendell Holmes Jr.</h2>
								</div>
							</li>
						</ul>
					</div>
				</section>
			
							<!-- FlexSlider -->
									  <script defer="" src="js/jquery.flexslider.js"></script>
									  <script type="text/javascript">
										$(function(){
										 
										});
										$(window).load(function(){
										  $('.flexslider').flexslider({
											animation: "slide",
											start: function(slider){
											  $('body').removeClass('loading');
											}
										  });
										});
									  </script>
								<!-- FlexSlider -->
			</div>
		</div>
	</div>
	<!--banner-end-->
	<!-- welcome -->
	<div class="mainbody">
		<div class="welcome">
			<div class="container">
				<div class="col-md-8 welcome-left">
					<h3>&nbsp;&nbsp;Features</h3>
					<div class="col-md-12 wel-rgt">
						<ul>
							<li class="feature">Streamlined Case Management: Centralize all your legal cases in one place. Easily create, update, and organize cases, ensuring nothing falls through the cracks.</li>
							<li class="feature">Secure Data Handling: We prioritize the security of your sensitive case information. Our robust encryption and access controls keep your data safe and confidential.</li>
							<li class="feature">Seamless Communication: Facilitate seamless communication between attorneys, clients, and other stakeholders. Our platform includes messaging and notification features for instant updates.</li>
							<li class="feature">Efficient Document Management: Upload, store, and access case-related documents securely. Version control and document tracking streamline your workflow.</li>
							<li class="feature">Deadline Tracking: Never miss an important date. Keep track of case deadlines, court appearances, and tasks, ensuring you're always prepared.</li>

						</ul><br><br>
						<a class="hvr-shutter-in-horizontal" href="https://www.cogneesol.com/blog/legal-case-management-system-for-law-firms/" target="_blank">Read More</a>
						<br>
						<br>
					</div>
				</div>
				<div class="col-md-4 welcome-right">
					<h3>Areas Of Practice</h3>
						<ul>
							<li><a href="#"><span></span>Civil Litigation</a></li>
							<li><a href="#"><span></span>Criminal Law</a></li>
							<li><a href="#"><span></span>Real Estate Law</a></li>
							<li><a href="#"><span></span>Bankruptcy Law </a></li>
							<li><a href="#"><span></span>Corporate and Business Law</a></li>
							<li><a href="#"><span></span>Immigration Law </a></li>
							<li><a href="#"><span></span>Intellectual Property Law</a></li>
							<li><a href="#"><span></span>Civil Rights Law</a></li>
							
						</ul>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<!-- welcome -->
		<!-- cases -->
		<div class="cases">
			<div class="container">
					<div class="col-md-4 cases-left">
						<h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Case Inquiry</h3>
						<div class="imgcontain">
							<a href="case_inquiry.html"><img src="images/case.jpg" alt="img1"  height="250" width="350" class="animationimg">
							<div class="overlay">
								<div class="text"></div>
							</div>
							</a>
						</div>
						<p>Seeking information, updates, or details about a your specific legal case ; Request information regarding a case's status, progress, or any related matters. Transparency helps maintain trust in the justice system and ensures accountability.</p>
						<a class="hvr-shutter-in-horizontal" href="#">Read More</a>

					</div>
					<div class="col-md-4 cases-left">
						<h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hire Lawyer</h3>
						<div class="imgcontain">
							<a href="hire_lawyer.html"><img src="images/lawyer.png" alt="img2" height="250" width="350" class="animationimg">
							<div class="overlay">
								<div class="text"></div>
							</div>
							</a>
						</div>
						<p>Unlock Legal Solutions with Confidence: Your Trusted Partner in Finding the Right Lawyer. We connect people with the appropriate legal professionals & assures our users that we'll help you identify the lawyer who is best suited to your particular needs and situation.</p>
						<a class="hvr-shutter-in-horizontal" href="#">Read More</a>
					</div>
					<div class="col-md-4 cases-left">
						<h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Legal Google</h3>
						<div class="imgcontain">
							<a href="legal_google"><img src="images/legal_google.jpg" alt="img3" height="250" width="350" class="animationimg">
							<div class="overlay">
								<div class="text"></div>
							</div>
							</a>
						</div>
						<p>A legal information portal is a digital platform that provides comprehensive and reliable information about various aspects of the law and legal matters. Our aim is to educate individuals, legal professionals, and businesses about their rights, responsibilities, and legal options.</p>
						<a class="hvr-shutter-in-horizontal" href="#">Read More</a>
					</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<!-- cases-end -->
		<!-- news -->
		<div class="news">
			<div class="container">
				<h3>News Portal & History</h3>
				<div class="col-md-6 news-left">
					<div class="col-md-6 new-lft">
						<a href="https://www.livelaw.in/tags/judiciary" target="_blank"><img src="images/news.png" alt=" "  class="animationimg" height="200" width="250"></a>
					</div>
					<div class="col-md-6 new-rgt">
						<p>News Portal : A digital platform for publishing, curating, and delivering news content to a wide audience.  It cover a wide range of topics, including politics, world events, business, sports, technology, and more.
							<br><a class="hvr-shutter-in-horizontal" href="https://www.livelaw.in/tags/judiciary">Read More</a>
						</div>
						<div class="clearfix"></div>
				</div>
				<div class="col-md-6 news-left">
					<div class="col-md-6 new-lft">
						<a href="https://blog.ipleaders.in/judicial-system-in-india/#:~:text=The%20first%20high%20court%20was,jurisdiction%20than%20the%20high%20courts." target="_blank"><img src="images/10.jpg" alt=" "  class="animationimg" height="200" width="250"></a>
					</div>
					<div class="col-md-6 new-rgt">
						<p>The history of the Indian judicial system is a complex and multifaceted journey that has evolved over millennia. Here is a summarized overview of the key historical developments in India's judicial system:<br>
					    <a class="hvr-shutter-in-horizontal" href="https://blog.ipleaders.in/judicial-system-in-india/#:~:text=The%20first%20high%20court%20was,jurisdiction%20than%20the%20high%20courts.">Read More</a>
					</div>
						<div class="clearfix"></div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<!-- news-end -->
	</div>
	<!-- footer-starts -->
	<div class="footer">
		<div class="container">
				<div class="col-md-4 contact-left">
				<h4>Address</h4>
					<div class="cont-tp">
						<span class="glyphicon glyphicon-map-marker" aria-hidden="true">
					</span></div>
					
					<address>
						Nr. Vasantnagar Township, <br>Gota-Ognaj Road, <br>Ahmedabad, GUJARAT- 382470<br>
					</address>
				</div>
				<div class="col-md-4 contact-left">
				<h4>Phone/Fax</h4>
					<div class="cont-tp">
						<span class="glyphicon glyphicon-phone" aria-hidden="true">
					</span></div>
					
					<p>Phone : +91-9510900587 </p>
					<p>Mail : info@aitindia.in</p>
					<p>Fax : +1234567890 </p>
				</div>
				<div class="col-md-4 contact-left">
				<h4>Newsletter</h4>
					<div class="cont-tp">
						<span class="glyphicon glyphicon-envelope" aria-hidden="true">
					</span></div>
					<form>
						<input type="text" value="Enter Your email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter Your email';}">
						<input type="submit" value="Subscribe">
					</form>
				</div>
				<div class="clearfix"></div>
			
			<div class="footer-text">
				<p>&copy; 2023 Legal Case Management. All rights reserved.</p>
			</div>
		</div>
	</div>
	<!-- footer-end -->
</body>
</html>