-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 01:37 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_register`
--

-- --------------------------------------------------------

--
-- Table structure for table `case_details`
--

CREATE TABLE `case_details` (
  `NO` int(11) NOT NULL,
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `descriptopn` varchar(1000) NOT NULL,
  `type` varchar(100) NOT NULL,
  `judg` varchar(100) NOT NULL,
  `lawy` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `pre` date NOT NULL,
  `next` date NOT NULL,
  `loc` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `case_details`
--

INSERT INTO `case_details` (`NO`, `id`, `name`, `descriptopn`, `type`, `judg`, `lawy`, `status`, `pre`, `next`, `loc`) VALUES
(2, 97927, 'Vikram Kapoor', 'The Kapoor Estate Inheritance Dispute is a civil case revolving around a contentious battle between two adult siblings, Ayesha and Vikram Kapoor, over the distribution of their deceased parents\' estate. Ayesha alleges that the most recent will is forged and that her younger brother, Vikram, exerted undue influence over their ailing parents, resulting in an unequal distribution of the estate in his favor. Vikram vehemently denies these claims, asserting that the new will accurately reflects their parents\' intentions, and that it was created with their full consent. ', '', 'Mr. D. M. Vyas', 'Advocate Shivang Lalan', '1st Hearing Done', '2023-03-07', '2023-09-26', 'Gheekanta Court Metropolitan Court'),
(3, 38820, 'Priyanshu Kapoor', 'The Employment Contract Dispute: Anderson vs. Horizon Corp is a civil case involving Priyanshu Patel, a former executive, and Horizon Corporation, his former employer. This case centers around allegations of breach of contract. James Anderson claims that Horizon Corp failed to honor the terms of his employment contract, which included promised bonuses and benefits. Horizon Corp, on the other hand, contends that Anderson did not fulfill certain performance-related obligations outlined in the contract, justifying their decision to withhold the agreed-upon compensation.', '', 'Mr. J. T. SHAH', 'Advocate Brijendra Singh', '2nd Hearing Done', '2023-03-15', '2023-09-28', ' City Civil And Sessions Court '),
(4, 47858, 'Wilson Anderson', 'The Contract Breach in Business case involves a bitter dispute between Anderson Partners, a small marketing agency, and Wilson Investments, a venture capital firm. Anderson Partners alleges that Wilson Investments breached their mutually agreed-upon contract by failing to provide the promised funding for a strategic marketing campaign. Anderson Partners claims that this breach led to financial losses and damage to their reputation. In response, Wilson Investments argues that Anderson Partners did not meet the contractual obligations and delivered subpar services, justifying their withholding of funds. ', '', 'Mr. A. M. Varma', 'Advocate Bakul S Panchal', 'Pending', '0000-00-00', '2023-09-29', 'Gheekanta Court Metropolitan Court'),
(5, 31830, 'Maya Singh', 'The Intellectual Property Infringement case, referred to as \"Artist vs. Artist,\" involves two artists, Maya Singh and Rahul Verma. Maya Singh has accused Rahul Verma of copyright infringement, claiming that Rahul used her original artwork without her permission to create and sell derivative pieces. Maya alleges that this unauthorized use of her work has harmed her reputation and livelihood as an artist. Rahul, on the other hand, asserts that his work was inspired by Maya\'s art but is a distinct creation in its own right and that he did not violate any copyright laws', '', 'Ms. S. S. P. Jain', 'Advocate Paresh M Modi', '2nd Hearing Done', '2023-01-10', '2023-09-23', ' City Civil And Sessions Court'),
(6, 96211, 'Rakesh Gupta', 'The Unpaid Loan Allegations: Gupta vs. Patel is a civil case involving two parties, Rakesh Gupta and Priya Patel. Mr. Gupta has taken legal action against Ms. Patel for her alleged failure to repay a significant loan. Gupta claims that he lent Patel a substantial sum of money with a clear agreement and timeline for repayment. However, Patel disputes the amount of the loan and argues that she has faced financial hardship that has made it difficult for her to meet the agreed-upon repayment terms. The court will be tasked with determining the validity of the loan agreement and assessing whether Patel is liable for repayment', '', 'Ms. R. A. Nagori', 'Advocate Jaimini Nayak', '2nd Hearing Done', '2023-04-15', '2023-09-20', ' Old High court Ahmedabad'),
(7, 81675, 'Anant Desai', 'The Employment Discrimination case of Patel vs. XYZ Corporation is a civil lawsuit brought by Anant Desai, a former employee, against his former employer, XYZ Corporation. He alleges that he was wrongfully terminated on the basis of his race and ethnicity, claiming that he was subjected to discriminatory treatment throughout his employment. He asserts that he was qualified for his position and performed his duties diligently but was terminated without just cause. XYZ Corporation denies the allegations, contending that his termination was based on legitimate performance-related issues. ', '', 'Mr. D. M. Vyas', 'Advocate Shalvi S Mehta', '1st Hearing Done', '2023-06-18', '2023-09-30', 'Gheekanta Court Metropolitan Court'),
(8, 88632, 'Siddharth Mehta', 'The Custody Battle: Mehtas vs. Carter is a civil case involving a divorced couple, Siddharth Mehta and Disha Carter, who are locked in a contentious legal battle over the custody of their two children. Siddharth and DIsha have contrasting views on what is in the best interest of their children, and both claim to be the more suitable parent. Sarah alleges that Disha\'s work schedule and lifestyle make him an unfit parent. The court will evaluate both parents\' fitness and parenting capabilities to determine the most suitable custody arrangement, keeping the children\'s well-being as the top priority', '', 'Mr. P. G. Soni', 'Advocate Chandan R Rajput', 'Pending', '0000-00-00', '2023-10-25', ' City Civil And Sessions Cour'),
(9, 81300, 'Raj Joshi', 'he Landlord-Tenant Dispute: Joshi vs. Jackson Properties is a civil case involving a tenant, Mr. Raj Joshi, and his landlord, Jackson Properties, LLC. Mr. Joshi has filed a lawsuit against Jackson Properties, alleging multiple issues with the rental property he occupies. He claims that the property has not been properly maintained, leading to safety concerns, health issues, and discomfort. ', '', 'Mr. N. N. Pathar', 'Advocate Aradhana Singh', '1st Hearing Done', '2023-08-09', '2023-10-14', 'Gheekanta Court Metropolitan Court'),
(10, 20664, 'Vikram Singhania', 'The Intellectual Property Infringement case, pitting one artist against another, involves a dispute over copyright infringement. The plaintiff, Jane Smith, alleges that the defendant, Alex Johnson, unlawfully used her original artwork without obtaining the necessary permissions or licensing rights. Jane claims that Alex\'s work incorporates elements of her artwork, violating her exclusive rights as the creator. In response, Alex contends that her work is independently created and not derived from Jane\'s art', '', 'Mr. V. K. Bansa', 'Advocate Mohammed Kutbuddin Vohra', 'Pending', '0000-00-00', '2023-10-31', 'City Civil And Sessions Court '),
(11, 75243, 'Mark Davis', 'The Personal Injury Lawsuit: Johnson vs. Davis is a civil case brought forth by Jane Johnson against Mark Davis. The case centers on a traffic accident in which Jane Johnson, a pedestrian, sustained serious injuries. Jane alleges that Mark Davis, the driver of the vehicle involved, was negligent and responsible for the accident. She claims that Mr. Davis failed to exercise due care while operating his vehicle, leading to the collision and her subsequent injuries. Jane is seeking compensation for her medical bills, pain and suffering, and other damages resulting from the accident ', '', 'Mr. B. H. Gandhi', 'Advocate Athar Amaan Hava', '1st Hearing Done', '2023-06-05', '2023-09-26', 'City Civil And Sessions Court'),
(12, 72955, 'John Smith', 'The Boundary Line Dispute: Smith vs. Johnson is a civil case involving two neighboring property owners, John Smith and Sarah Johnson. This case revolves around a disagreement over the location of their property boundary. The dispute escalated when an argument between the neighbors turned physical, resulting in property damage. Both parties have provided conflicting evidence and arguments regarding the accurate demarcation of the boundary. The court will determine the correct boundary line and assess liability for the property damage incurred during the disput', '', 'Ms. P. N. Dave', 'Advocate G G Shaikh', '1st Hearing Done', '2023-07-02', '2023-09-27', 'Old High court Ahmedabad'),
(13, 25732, 'Pooja Reddy', 'The Environmental Contamination Lawsuit: Residents vs. Factory Co. is a civil case involving a group of residents living near a manufacturing factory owned by Factory Co. The residents allege that pollution emitted from the factory, including air and water pollution, has caused harm to their health and has negatively impacted their property values. They claim that the factory\'s operations have resulted in respiratory issues, contaminated groundwater, and a decline in the value of their homes. ', '', 'Mr. D. D. Buddhdev', 'Advocate Vivek Mapara', '2nd Hearing Done', '2023-02-14', '2023-09-28', 'Gheekanta Court Metropolitan Court'),
(14, 58653, 'Priya Patel', 'The Defamation Case: Patel vs. The Daily Gazette is a civil lawsuit filed by Ms. Priya Patel against the prominent newspaper, The Daily Gazette. The case centers on allegations of defamation. Ms. Patel claims that the newspaper published false and damaging information about her, which significantly harmed her personal and professional reputation. She contends that the newspaper\'s reporting was not based on accurate facts and was published with a reckless disregard for the truth', '', 'Mrs. S. P. Chopra ', 'Advocate Abhishek Mukherjee', 'Pending', '0000-00-00', '2023-09-23', 'City Civil And Sessions Court'),
(15, 72770, 'Emily Roberts', 'The Defamation Case: Roberts vs. The Daily Gazette is a civil lawsuit brought forth by an individual named Emily Roberts against the newspaper \"The Daily Gazette.\" Ms. Roberts alleges that the newspaper published false and damaging information about her, leading to harm to her personal and professional reputation. She claims that the article contained defamatory statements that were not backed by any verifiable evidence. In her lawsuit, Ms. Roberts seeks legal remedies and damages for the harm caused to her reputation as a result of the publication.', '', 'Mr. K. N. Nimavat', 'Advocate Narendra Ramnani', 'pending', '0000-00-00', '2023-10-04', 'Old High court Ahmedabad'),
(16, 17970, 'Ayesha Khan', 'The Construction Project Delays case pits Smith Construction, a contracting company, against Peterson Properties, a property development firm. This civil case centers on a construction project that experienced significant delays and cost overruns. Peterson Properties hired Smith Construction to build a commercial complex with a strict timeline and budget', '', 'Mr. H. R. Patel', 'Advocate Srushti Thula', '2nd Hearing Done', '2023-07-03', '2023-09-29', 'Old High court Ahmedabad');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(1) NOT NULL,
  `full_name` varchar(128) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `password`) VALUES
(3, 'Meet', 'xyz@gmail.com', ''),
(4, 'Meet', 'katarmalmeet851@gmail.com', '$2y$10$nVrMMVumNwQ7nubnKvDydeWXnopLjIMJYnzNL1ZFkDQBTnS/O6Wfq'),
(5, 'meet', 'mnu@gmail.com', '$2y$10$5TKso9qCHz4ZnWEs1MsgrOlsGt6YbeBYBcqzUFaADHMt8Ad7yMTe6');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `case_details`
--
ALTER TABLE `case_details`
  ADD PRIMARY KEY (`NO`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `case_details`
--
ALTER TABLE `case_details`
  MODIFY `NO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
