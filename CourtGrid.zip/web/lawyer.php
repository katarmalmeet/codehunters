<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Case Grid | Where Legal Cases Meet Efficiency</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Law Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,400,300,600,700|Six+Caps' rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$("#employee_div").load("allrecord.php");
		$("#depart_dropdown").change(function(){
			var selected=$(this).val();
			$("#desig_div").load("desig.php",{selected_depart: selected});
		});
		$("#refresh").click(function(){
			$("#employee_div").load("allrecord.php");
		});

	});
</script>


<style>
	.feature {
		background: #efd4d0;
		margin-bottom: 60px;
	}
	#homie {
		margin-left: 120px;
	}

	li.space {
		margin-left: 27px;
	}
	div.container {
		margin: 20px;
		padding: 0px 0px;
		width: 90%;
	}
	
	.head-main {
		width: 300px;
	}

</style>


</head>
<body>	<!--header-top-starts-->
	<div class="header-top">
		<div class="container">
			<div class="head-main">
				<h1>
					<a href="index3.php"><img src="images/law_icon.png" alt="Image File" height="50">CaseGrid</a>
				</h1>
			</div>
			<div class="navigation">
				<nav class="navbar navbar-default" role="navigation">
					<!--/.navbar-header-->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">
							<li class="active" id="homie"><a href="index3.php">Home</a></li>
							<li class="space"><a href="case_inquiry.php">Case Inquiry</a></li>
							<li class="space"><a href="lawyer.php">Hire Lawyer</a></li>
							<li class="space"><a href="legal_google.php">Legal Google</a></li>
							<li class="space"><a href="about.php">About</a></li>
							<li class="space"><a href="contact.php">Contact</a></li>
						</ul>
					</div>
					<!--/.navbar-collapse-->
				</nav>
			</div>
			<div class="hea-rgt">
				<a href="logout.php">Lougout</a>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<!--header-top-end-->
	<!--start-header-->
	<!--
	
	<div class="header">
		<div class="container">
			<div class="head">
				<div class="soc">
					<ul>
						<li><a href="#"><span class="fb"> </span></a></li>
						<li><a href="#"><span class="twit"> </span></a></li>
						<li><a href="#"><span class="pin"> </span></a></li>
						<li><a href="#"><span class="rss"> </span></a></li>
						<li><a href="#"><span class="drbl"> </span></a></li>
						<div class="clearfix"></div>
					</ul>
				</div>
				<div class="header-right">
					<div class="search-bar">
						<form>
							<input type="text" value="Search" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search';}">
							<input type="submit" value="">
						</form>
					</div>
				</div>
				
					<div class="clearfix"></div>
			</div>
		</div>
	</div>	
	
	-->
	<!-- script-for-menu -->
	<!-- script-for-menu -->
		<script>
			$("span.menu").click(function(){
				$(" ul.navig").slideToggle("slow" , function(){
				});
			});
		</script>
	<!-- script-for-menu -->
				

	<!-- banner-starts -->
	<div class="banner-1">
		
	</div>
	<!--banner-end-->
	<div class="welcome">
	<div class="container">	
	<center><h1><strong>Get a perfect Lawyer for your case</strong></h1></center>
	<br>
		<div class="row">
			<form method="post" class="form-horizontal">
				<label for="price" class="control-label col-sm-3 col-sm-offset-2" >Case type: </label>
					<div class="col-sm-2" >
						<select name="department" class="form-control" id="depart_dropdown">
							<option>---Select---</option>
							<?php
								require('config.php');
								$db = new db;
								$result=$db->getDepartment();
								while($row=mysqli_fetch_array($result)){
									echo "<option value=".$row['depart_id'].">".$row['depart_name']."</option>";	
								}
								$db->closeCon();
							?>
						</select>
						
					</div>
					<div class="col-sm-2" id="desig_div">
						
					</div>
						<button type="button" name="refresh" id="refresh" class="btn btn-primary">Refresh</button>
			</form>
			
		</div>
		<div class="row"><br></div>
		<div class="row" id='employee_div'>
			
		</div>
	</div>
	</div>
	</div>

    <div class="mainbody">






    </div>
	<!-- footer-starts -->
	<div class="footer">
		<div class="container">
				<div class="col-md-4 contact-left">
				<h4>Address</h4>
					<div class="cont-tp">
						<span class="glyphicon glyphicon-map-marker" aria-hidden="true">
					</span></div>
					
					<address>
						Nr. Vasantnagar Township, <br>Gota-Ognaj Road, <br>Ahmedabad, GUJARAT- 382470<br>
					</address>
				</div>
				<div class="col-md-4 contact-left">
				<h4>Phone/Fax</h4>
					<div class="cont-tp">
						<span class="glyphicon glyphicon-phone" aria-hidden="true">
					</span></div>
					
					<p>Phone : +91-9510900587 </p>
					<p>Mail : info@aitindia.in</p>
					<p>Fax : +1234567890 </p>
				</div>
				<div class="col-md-4 contact-left">
				<h4>Newsletter</h4>
					<div class="cont-tp">
						<span class="glyphicon glyphicon-envelope" aria-hidden="true">
					</span></div>
					<form>
						<input type="text" value="Enter Your email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter Your email';}">
						<input type="submit" value="Subscribe">
					</form>
				</div>
				<div class="clearfix"></div>
			
			<div class="footer-text">
				<p>&copy; 2023 Legal Case Management. All rights reserved.</p>
			</div>
		</div>
	</div>
	<!-- footer-end -->
</body>
</html>