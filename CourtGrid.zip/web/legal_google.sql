-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 01:36 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `legal_google`
--

-- --------------------------------------------------------

--
-- Table structure for table `department_master`
--

CREATE TABLE `department_master` (
  `depart_id` int(11) NOT NULL,
  `depart_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `department_master`
--

INSERT INTO `department_master` (`depart_id`, `depart_name`) VALUES
(1, 'Tort claims'),
(2, 'Breach of contract claims'),
(4, 'Equitable claims'),
(5, 'Landlord/tenant issues'),
(6, 're-filing'),
(7, 'Initial pleading\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `designation_master`
--

CREATE TABLE `designation_master` (
  `desig_id` int(11) NOT NULL,
  `desig_name` text NOT NULL,
  `depart_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `designation_master`
--

INSERT INTO `designation_master` (`desig_id`, `desig_name`, `depart_id`) VALUES
(1, 'India', 1),
(2, 'Sri Lanka', 1),
(3, 'Pakistan', 1),
(4, 'Bangladesh', 2),
(5, 'China', 2),
(6, 'Afghanistan', 2),
(7, 'UK', 4),
(8, 'London', 4),
(9, 'France', 5),
(10, 'Germany', 5),
(11, 'Japan', 5),
(12, 'Russia', 6),
(13, 'Africa', 6),
(14, 'New Zealand', 7),
(15, 'Nepal\r\n', 7);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `emp_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `phone` varchar(600) NOT NULL,
  `email` text NOT NULL,
  `emp_address` text NOT NULL,
  `desig_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`emp_id`, `name`, `phone`, `email`, `emp_address`, `desig_id`) VALUES
(1, 'Ramesh', '16546644646', 'demoemail@email.com', 'xyz', 1),
(2, 'Suresh', '646594664', 'demoemail@email.com', 'dys', 4),
(3, 'Mahesh', '546164946464', 'demoemail@email.com', 'dsdrf', 6),
(4, 'Kamesh', '54574567352', 'demoemail@email.com', 'dsfsf', 5),
(5, 'Yogesh', '5757524524', 'demoemail@email.com', 'fedfg', 6),
(6, 'Ramanand', '78541555454', 'demoemail@email.com', 'fwrwr', 2),
(7, 'Parshav', '455454545', 'demoemail@email.com', 'fsrdasd', 10),
(8, 'Rahul', '4757542452', 'demoemail@email.com', 'daedw', 3),
(9, 'Damini', '1235575558', 'demoemail@email.com', 'resst', 6),
(10, 'Jagruti', '78547547855', 'demoemail@email.com', 'frwaraq', 3),
(11, 'Shobha', '27575775765', 'demoemail@email.com', 'dsfsdf', 6),
(12, 'Anjali', '12578845', 'demoemail@email.com', 'dwrfsfg', 10),
(13, 'Maya', '78447855878', 'demoemail@email.com', 'dsfge', 7),
(14, 'Jolit', '9865423755', 'demoemail@email.com', 'ewtsdg', 8),
(15, 'Ashok', '87545455555', 'demoemail@email.com', 'ewtg', 9),
(16, 'Dipak', '98547864785', 'demoemail@email.com', 'sarfdhg', 3),
(17, 'Ronak', '975475445445', 'demoemail@email.com', 'eqwrwa', 11),
(18, 'Kalpesh', '97854245555', 'demoemail@email.com', 'afssgv', 12),
(19, 'Darshan', '852456755', 'demoemail@email.com', 'derestyh', 6),
(20, 'Ravi', '878425555665', 'demoemail@email.com', 'ghjhmh', 11),
(21, 'Riddhi', '123577554785', 'demoemail@email.com', 'kyhfges', 11),
(22, 'Pooja', '5574445544', 'demoemail@email.com', 'arfwsgtf', 10),
(23, 'Amit', '75875652747', 'demoemail@email.com', 'dsfsdgf', 13),
(24, 'Preet', '4575757545', 'demoemail@email.com', 'adwfr', 10),
(25, 'Kaushal', '6545287795', 'demoemail@email.com', 'edwafawt', 14),
(26, 'Vishal', '56878744547', 'demoemail@email.com', 'dwageshg', 3),
(27, 'Vrushabh', '8562146556', 'demoemail@email.com', 'frhgj', 3),
(28, 'Charmi', '78546987123', 'demoemail@email.com', 'dfegdfhfg', 15),
(29, 'Chintan', '8754855555', 'demoemail@email.com', 'fsgfdhg', 11),
(30, 'Jagdish', '98544556555', 'demoemail@email.com', 'dhfhs', 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department_master`
--
ALTER TABLE `department_master`
  ADD PRIMARY KEY (`depart_id`);

--
-- Indexes for table `designation_master`
--
ALTER TABLE `designation_master`
  ADD PRIMARY KEY (`desig_id`),
  ADD KEY `depart_id` (`depart_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`emp_id`),
  ADD KEY `desig_id` (`desig_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `department_master`
--
ALTER TABLE `department_master`
  MODIFY `depart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `designation_master`
--
ALTER TABLE `designation_master`
  MODIFY `desig_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `designation_master`
--
ALTER TABLE `designation_master`
  ADD CONSTRAINT `designation_master_ibfk_1` FOREIGN KEY (`depart_id`) REFERENCES `department_master` (`depart_id`);

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`desig_id`) REFERENCES `designation_master` (`desig_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
