<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
include 'connect.php';
?>
<!DOCTYPE html>
<html>
<head>
<title>Case Grid | Where Legal Cases Meet Efficiency</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Law Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,400,300,600,700|Six+Caps' rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>

<style>
	.feature {
		background: #efd4d0;
		margin-bottom: 60px;
	}
	#homie {
		margin-left: 120px;
	}

	li.space {
		margin-left: 27px;
	}
	div.container {
		margin: 20px;
		padding: 0px 0px;
		width: 90%;
	}
	
	.head-main {
		width: 300px;
	}
	
</style>


</head>
<body>	<!--header-top-starts-->
	<div class="header-top">
		<div class="container">
			<div class="head-main">
				<h1>
					<a href="index3.php"><img src="images/law_icon.png" alt="Image File" height="50">CaseGrid</a>
				</h1>
			</div>
			<div class="navigation">
				<nav class="navbar navbar-default" role="navigation">
					<!--/.navbar-header-->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">
							<li class="active" id="homie"><a href="index3.php">Home</a></li>
							<li class="space"><a href="case_inquiry.php">Case Inquiry</a></li>
							<li class="space"><a href="lawyer.php">Hire Lawyer</a></li>
							<li class="space"><a href="legal_google.php">Legal Google</a></li>
							<li class="space"><a href="about.php">About</a></li>
							<li class="space"><a href="contact.php">Contact</a></li>
						</ul>
					</div>
					<!--/.navbar-collapse-->
				</nav>
			</div>
			<div class="hea-rgt">
				<a href="logout.php">Logout</a>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<!--header-top-end-->
	<!--start-header-->
	<!--
	
	<div class="header">
		<div class="container">
			<div class="head">
				<div class="soc">
					<ul>
						<li><a href="#"><span class="fb"> </span></a></li>
						<li><a href="#"><span class="twit"> </span></a></li>
						<li><a href="#"><span class="pin"> </span></a></li>
						<li><a href="#"><span class="rss"> </span></a></li>
						<li><a href="#"><span class="drbl"> </span></a></li>
						<div class="clearfix"></div>
					</ul>
				</div>
				<div class="header-right">
					<div class="search-bar">
						<form>
							<input type="text" value="Search" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search';}">
							<input type="submit" value="">
						</form>
					</div>
				</div>
				
					<div class="clearfix"></div>
			</div>
		</div>
	</div>	
	
	-->
	<!-- script-for-menu -->
	<!-- script-for-menu -->
		<script>
			$("span.menu").click(function(){
				$(" ul.navig").slideToggle("slow" , function(){
				});
			});
		</script>
	<!-- script-for-menu -->
				

	<!-- banner-starts -->
	<div class="banner-1">
		
	</div>
	<!--banner-end-->
	<div class="welcome">
		
	<div class="container">
        <div class="row">
            <div class="col-md-12 mt-4">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-tittle">Case Details</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <form method="post">
                                <div class="input-group flex-nowrap" >
                                    <input type="text" name="get_id" class="form-control" placeholder="Username/Case ID" aria-label="Username" aria-describedby="addon-wrapping" required>
                                    </div>
                                    <button type="submit" name="search_by_id" class="btn btn-primary mt-4">Search</button>
                                </form>
                                
                            </div>
                        </div>
                        <?php
                        if(isset($_POST['search_by_id'])){
                        $id =$_POST['get_id'];
                        $query="Select * from `case_details` Where id='$id'or name = '$id'";
                        $query_run = mysqli_query($con,$query);
                        ?>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Description</th>
                                        <th scope="col">Type</th>
                                        <th scope="col">Case Judge</th>
                                        <th scope="col">Case Lawyer</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Previous Hearing</th>
                                        <th scope="col">Next Hearing</th>
                                        <th scope="col">Location</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                     if(mysqli_num_rows($query_run)>0){
                                        while($row = mysqli_fetch_assoc($query_run)){
                                    
                                    ?>


                                    <tr>
                                        <th><?php echo $row['id']; ?></th>
                                        <th><?php echo $row['name']; ?></th>
                                        <th><?php echo $row['descriptopn']; ?></th>
                                        <th><?php echo $row['type']; ?></th>
                                        <th><?php echo $row['judg']; ?></th>
                                        <th><?php echo $row['lawy']; ?></th>
                                        <th><?php echo $row['status']; ?></th>
                                        <th><?php echo $row['pre']; ?></th>
                                        <th><?php echo $row['next']; ?></th>
                                        <th><?php echo $row['loc']; ?></th>
                                    </tr>
                                    <?php
                                    }

                                }
                                else{
                                   ?>
                                   <tr>
                                    <td colspan="10">No Record Found</td>
                                   </tr>
                                   <?php
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <?php
                            }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

	</div>
    <div class="mainbody">






    </div>
	<!-- footer-starts -->
	<div class="footer">
		<div class="container">
				<div class="col-md-4 contact-left">
				<h4>Address</h4>
					<div class="cont-tp">
						<span class="glyphicon glyphicon-map-marker" aria-hidden="true">
					</span></div>
					
					<address>
						Nr. Vasantnagar Township, <br>Gota-Ognaj Road, <br>Ahmedabad, GUJARAT- 382470<br>
					</address>
				</div>
				<div class="col-md-4 contact-left">
				<h4>Phone/Fax</h4>
					<div class="cont-tp">
						<span class="glyphicon glyphicon-phone" aria-hidden="true">
					</span></div>
					
					<p>Phone : +91-9510900587 </p>
					<p>Mail : info@aitindia.in</p>
					<p>Fax : +1234567890 </p>
				</div>
				<div class="col-md-4 contact-left">
				<h4>Newsletter</h4>
					<div class="cont-tp">
						<span class="glyphicon glyphicon-envelope" aria-hidden="true">
					</span></div>
					<form>
						<input type="text" value="Enter Your email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter Your email';}">
						<input type="submit" value="Subscribe">
					</form>
				</div>
				<div class="clearfix"></div>
			
			<div class="footer-text">
				<p>&copy; 2023 Legal Case Management. All rights reserved.</p>
			</div>
		</div>
	</div>
	<!-- footer-end -->
</body>
</html>